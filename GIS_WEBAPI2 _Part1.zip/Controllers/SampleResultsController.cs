﻿using GIS_WebAPI2.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Dynamic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web.Http;
using System.Web.Script.Serialization;

namespace GIS_WebAPI2.Controllers
{
    public class SampleResultsController : ApiController
    {
        public IHttpActionResult Get(String pid,int startNumber=0)
        {

            var result = new List<Dictionary<string, object>>();

            //DataSet DS = new DataSet();
            DataTable DT = new DataTable();
            Samples sp = new Models.Samples();
            DT = sp.results(pid, startNumber);

            foreach (DataRow row in DT.Rows)
            {
                Dictionary<string, object> obj = new Dictionary<string, object>();
                foreach (DataColumn col in DT.Columns)
                {
                    obj.Add(col.ColumnName, row[col.ColumnName]);
                }
                result.Add(obj);
            }

            var serializer = new JavaScriptSerializer();
            serializer.MaxJsonLength = 867530900;

            return Ok(result);
        }

        //public string DataTableToJSONWithStringBuilder(DataTable table)
        //{
        //    var JSONString = new StringBuilder();
        //    if (table.Rows.Count > 0)
        //    {
        //        JSONString.Append("[");
        //        for (int i = 0; i < table.Rows.Count; i++)
        //        {
        //            JSONString.Append("{");
        //            for (int j = 0; j < table.Columns.Count; j++)
        //            {
        //                if (j < table.Columns.Count - 1)
        //                {
        //                    JSONString.Append("\"" + table.Columns[j].ColumnName.ToString() + "\":" + "\"" + table.Rows[i][j].ToString() + "\",");
        //                }
        //                else if (j == table.Columns.Count - 1)
        //                {
        //                    JSONString.Append("\"" + table.Columns[j].ColumnName.ToString() + "\":" + "\"" + table.Rows[i][j].ToString() + "\"");
        //                }
        //            }
        //            if (i == table.Rows.Count - 1)
        //            {
        //                JSONString.Append("}");
        //            }
        //            else
        //            {
        //                JSONString.Append("},");
        //            }
        //        }
        //        JSONString.Append("]");
        //    }
        //    return JSONString.ToString();
        //}
        
    }
}
