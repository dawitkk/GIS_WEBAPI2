﻿using System.Collections.Generic;
using System.Web.Http;
using GIS_WebAPI2.Models;
using System.Data;
using System.Dynamic;

namespace GIS_WebAPI2.Controllers
{
    public class TestController : ApiController
    {
        //[HttpGet]
        public IHttpActionResult Post()
        {

            return Ok(new List<int>() { 1, 2, 3 });
        }
                
        public IHttpActionResult Get()
        {

            var result = new List<dynamic>();

            DataSet DS = new DataSet();
            Samples sp = new Models.Samples();
            DS = sp.project("Chalk Creek Mining District");

            foreach (DataRow row in DS.Tables[0].Rows)
            {
                var obj = (IDictionary<string, object>)new ExpandoObject();
                foreach (DataColumn col in DS.Tables[0].Columns)
                {
                    obj.Add(col.ColumnName, row[col.ColumnName]);
                }
                result.Add(obj);
            }

            return Ok(result);
        }
    }
}
