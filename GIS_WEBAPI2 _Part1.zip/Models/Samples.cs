﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;

namespace GIS_WebAPI2.Models
{ 
    public class Samples
    {
        
        public DataSet project(string prj)
        {
            String tconnString = System.Web.Configuration.WebConfigurationManager.ConnectionStrings["ScribedbConnection"].ConnectionString.ToString();
            //String selectCmd = String.Format("select PROJECTID from dbo.LOGINS where PROJECT_ALIAS = '{0}'", prj);

            //String selectCmd = String.Format("select PROJECTID, PROJECT_ALIAS from dbo.LOGINS where PROJECT_ALIAS is not null");CONVERT(date, getdate())

            String selectCmd = "select l.*, FORMAT(l.Date_Collected, 'M/d/yyyy HH:mm:ss') as Date, CASE WHEN l.Result is NULL and(l.Result_Qualifier is not null) THEN '< ' + CAST(l.MDL as VARCHAR(15)) + ' ' + l.Result_Units WHEN l.Result is not null and l.Result_Qualifier is not null THEN CAST(l.Result as VARCHAR(20)) +' ' + l.Result_Units + ' ' + l.Result_Qualifier + '' ELSE CAST(l.Result as VARCHAR(20)) +' ' + l.Result_Units END as Resultq, s.Location, s.Sub_Location, g.Latitude, g.Longitude, g.Location_Image_Path, s.SampleType, s.Samp_Depth_To, s.Samp_Depth_Units, m.Matrix, s.Samp_Depth from dbo.PID_2792_LabResults l INNER JOIN dbo.PID_2792_Samples s ON s.Samp_No = l.Samp_No LEFT JOIN dbo.PID_2792_SamplesWater w ON s.Samp_No = w.Samp_No LEFT JOIN dbo.PID_2792_Location g ON s.Location = g.Location LEFT JOIN dbo.LookupMatrix m ON s.Matrix = m.SMatrix where Date_Collected IS NOT NULL";

         SqlConnection myConnection =
                new SqlConnection(tconnString);
            SqlDataAdapter myCommand = new SqlDataAdapter(selectCmd, myConnection);

			// set the CommandTimeout
			myCommand.SelectCommand.CommandTimeout = 120;  // seconds

			DataSet ds = new DataSet();
            myCommand.Fill(ds, "Project");

            return ds;
        }              
        
        public DataSet projects()
        {
            String tconnString = System.Web.Configuration.WebConfigurationManager.ConnectionStrings["ScribedbConnection"].ConnectionString.ToString();
            //String selectCmd = String.Format("select PROJECTID from dbo.LOGINS where PROJECT_ALIAS = '{0}'", prj);

            String selectCmd = String.Format("select PROJECTID, PROJECT_ALIAS from dbo.LOGINS where PROJECT_ALIAS is not null ORDER BY PROJECT_ALIAS");
                       
            SqlConnection myConnection =
                   new SqlConnection(tconnString);
            SqlDataAdapter myCommand = new SqlDataAdapter(selectCmd, myConnection);

			// set the CommandTimeout
			myCommand.SelectCommand.CommandTimeout = 60;  // seconds

			DataSet ds = new DataSet();
            myCommand.Fill(ds, "Projects");

            return ds;
        }

        public DataTable results(string pid, int startNumber=0)
        {
            String tconnString = System.Web.Configuration.WebConfigurationManager.ConnectionStrings["ScribedbConnection"].ConnectionString.ToString();
            
            String selectCmd = String.Format("select l.*, w.*, FORMAT(l.Date_Collected, 'MM/dd/yyyy HH:mm:ss') as Date, CASE WHEN l.Result is NULL and(l.Result_Qualifier is not null) THEN '< ' + CAST(l.MDL as VARCHAR(15)) + ' ' + l.Result_Units WHEN l.Result is not null and l.Result_Qualifier is not null THEN CAST(l.Result as VARCHAR(20)) +' ' + l.Result_Units + ' ' + l.Result_Qualifier + '' ELSE CAST(l.Result as VARCHAR(20)) +' ' + l.Result_Units END as Resultq, s.Location, s.Sub_Location, g.Latitude, g.Longitude, g.Location_Image_Path, s.SampleType, s.Samp_Depth_To, s.Samp_Depth_Units, m.Matrix, s.Samp_Depth from dbo.PID_{0}_LabResults l INNER JOIN dbo.PID_{0}_Samples s ON s.Samp_No = l.Samp_No LEFT JOIN dbo.PID_{0}_SamplesWater w ON s.Samp_No = w.Samp_No LEFT JOIN dbo.PID_{0}_Location g ON s.Location = g.Location LEFT JOIN dbo.LookupMatrix m ON s.Matrix = m.SMatrix where Date_Collected IS NOT NULL ORDER BY l.LabResultsID offset {1} rows fetch next 5000 rows only", pid, startNumber);

            SqlConnection myConnection =
                   new SqlConnection(tconnString);
            SqlDataAdapter myCommand = new SqlDataAdapter(selectCmd, myConnection);

			// set the CommandTimeout
			myCommand.SelectCommand.CommandTimeout = 120;  // seconds

			DataSet ds = new DataSet();
            myCommand.Fill(ds, "results");

            return ds.Tables[0];
            
        }

		public DataTable resultsPivot(string pid, int startNumber=0)
		{
			String tconnString = System.Web.Configuration.WebConfigurationManager.ConnectionStrings["ScribedbConnection"].ConnectionString.ToString();

			String selectCmd = "select DISTINCT Analyte from dbo.PID_" + pid +"_LabResults as s where (Analyte IS NOT NULL)";			

			SqlConnection myConnection =
				   new SqlConnection(tconnString);
			SqlDataAdapter myCommand = new SqlDataAdapter(selectCmd, myConnection);

			// set the CommandTimeout
			myCommand.SelectCommand.CommandTimeout = 60;  // seconds

			DataSet ds = new DataSet();
			myCommand.Fill(ds, "analytes");

			string crosstabAnalytes = "";
			string pivotAnalytes = "";

			foreach (DataRow row in ds.Tables[0].Rows)
			{

				var value = row.Field<string>("Analyte");

				if (value == "" || value == null)
					continue;

				if (crosstabAnalytes == "")
				{
					if (value.Contains('[') && value.Contains(']'))
					{
						crosstabAnalytes = crosstabAnalytes + "Max([" + value.Replace("]", "]]") + "]) as " + '"' + value + '"';
						pivotAnalytes = "[" + value.Replace("]", "]]") + "]";
					}
					else
					{
						crosstabAnalytes = crosstabAnalytes + "Max([" + value + "]) as " + '"' + value + '"';
						pivotAnalytes = "[" + value + "]";
					}

				}
				else
				{
					if (value.Contains('[') && value.Contains(']'))
					{
						crosstabAnalytes = crosstabAnalytes + ", Max([" + value.Replace("]", "]]") + "]) as " + '"' + value + '"';
						pivotAnalytes = pivotAnalytes + ", [" + value.Replace("]", "]]") + "]";
					}
					else
					{
						crosstabAnalytes = crosstabAnalytes + ", Max([" + value + "]) as " + '"' + value + '"';
						pivotAnalytes = pivotAnalytes + ", [" + value + "]";
					}
				}

			}

			selectCmd = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS where TABLE_NAME = 'PID_" + pid + "_SamplesWater'";

			myCommand = new SqlDataAdapter(selectCmd, myConnection);

			// set the CommandTimeout
			myCommand.SelectCommand.CommandTimeout = 60;  // seconds

			ds = new DataSet();
			myCommand.Fill(ds, "fparams");

			string[] fparams = new string[] {"Color", "Conductivity", "Diss_O2", "Flow", "Odor", "ORP", "pH", "Salinity", "Temp", "Turbidity"};

		    string bparams = "";

			foreach (DataRow row in ds.Tables[0].Rows)
			{

				var value = row.Field<string>("COLUMN_NAME");
				if (fparams.Contains(value)) {

					if (bparams == "")
						bparams = bparams + "Max([" + value + "]) as " + '"' + value + '"'; 
					else
						bparams = bparams + ", Max([" + value + "]) as " + '"' + value + '"';

				}

			}	

			selectCmd = String.Format("select l.*, FORMAT(l.Date_Collected, 'MM/dd/yyyy HH:mm:ss') as Date, s.Location, s.Sub_Location, g.Latitude, g.Longitude, g.Location_Image_Path, " +
				"s.SampleType, s.Samp_Depth_To, s.Samp_Depth_Units, m.Matrix, s.Samp_Depth from dbo.PID_{0}_LabResults l INNER JOIN dbo.PID_{0}_Samples s " +
				"ON s.Samp_No = l.Samp_No LEFT JOIN dbo.PID_{0}_SamplesWater w ON s.Samp_No = w.Samp_No LEFT JOIN dbo.PID_{0}_Location g " +
				"ON s.Location = g.Location LEFT JOIN dbo.LookupMatrix m ON s.Matrix = m.SMatrix where Date_Collected IS NOT NULL ", pid);

			string pivotQuerytxt2 = String.Format("Select CAST(ROW_NUMBER() OVER (ORDER BY  Location) AS varchar(8)) AS ID, Location, Max(SampleType) as SampleType, Date_Collected as Date, " +
				"Analysis, Max(Matrix) as Matrix, Samp_No, Max(Latitude) as Latitude, Max(Longitude) as Longitude, {0}, Result_Units as Units, Result_Qualifier as Qualifier  from (" + selectCmd + ") " +
				"as p pivot ( Max(Result) for Analyte in ({1})) as G Group By Location, Date_Collected, Analysis, Samp_No, Result_Units, Result_Qualifier ", crosstabAnalytes, pivotAnalytes);

			string pivotQuerytxt = String.Format("Select CAST(ROW_NUMBER() OVER (ORDER BY  Location) AS varchar(8)) AS ID, Location, Max(SampleType) as SampleType, Date_Collected as Date, " +
				"Analysis, Max(Matrix) as Matrix, G.Samp_No, Max(Latitude) as Latitude, Max(Longitude) as Longitude, {0}, Result_Units as Units, Result_Qualifier as Qualifier, {2}  from (" + selectCmd + ") " +
				"as p pivot ( Max(Result) for Analyte in ({1})) as G LEFT JOIN dbo.PID_{3}_SamplesWater w ON G.Samp_No = w.Samp_No Group By Location, Date_Collected, Analysis, G.Samp_No, Result_Units, Result_Qualifier ORDER BY Date_Collected ", crosstabAnalytes, pivotAnalytes, bparams, pid);


			myCommand = new SqlDataAdapter(pivotQuerytxt, myConnection);

			// set the CommandTimeout
			myCommand.SelectCommand.CommandTimeout = 120;  // seconds

			ds = new DataSet();
			myCommand.Fill(ds, "Pivot");

			return ds.Tables[0];

		}

		public DataSet fieldparams(string pid)
        {
            String tconnString = System.Web.Configuration.WebConfigurationManager.ConnectionStrings["ScribedbConnection"].ConnectionString.ToString();

            String selectCmd = String.Format("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'PID_{0}_SamplesWater'", pid);

            SqlConnection myConnection =
                   new SqlConnection(tconnString);
            SqlDataAdapter myCommand = new SqlDataAdapter(selectCmd, myConnection);

			// set the CommandTimeout
			myCommand.SelectCommand.CommandTimeout = 60;  // seconds

			DataSet ds = new DataSet();
            myCommand.Fill(ds, "Fieldparams");

            return ds;
        }

		public DataTable toGPO(int pid, int startNumber=0) {

			String tconnString = System.Web.Configuration.WebConfigurationManager.ConnectionStrings["ScribedbConnection"].ConnectionString.ToString();

			String selectCmd = String.Format("SELECT l.Analysis, l.Analyte, l.Date_Collected, l.Lab_Result_Qualifier, l.Lab_Samp_No, l.MDL, l.Result, l.Result_Text, l.Result_Units, l.Samp_No, l.Sample_Type_Code, l.Total_Or_Disolved, s.Location, g.Latitude," +
										 "g.Longitude, s.SampleType, s.Samp_Depth, s.Samp_Depth_To, m.Matrix, w.pH, w.Temp, w.Flow, w.Conductivity, l.QA_Comment, l.Reporting_Limit "+
										 "FROM dbo.PID_{0}_LabResults AS l INNER JOIN dbo.PID_{0}_Samples AS s ON s.Samp_No = l.Samp_No LEFT OUTER JOIN " +
										 "dbo.PID_{0}_SamplesWater AS w ON s.Samp_No = w.Samp_No LEFT OUTER JOIN dbo.PID_{0}_Location AS g ON s.Location = g.Location LEFT OUTER JOIN " +
										 "dbo.lookupmatrix AS m ON s.Matrix = m.SMatrix WHERE(l.Date_Collected IS NOT NULL) ORDER BY l.Date_Collected", pid);

			SqlConnection myConnection =
				   new SqlConnection(tconnString);
			SqlDataAdapter myCommand = new SqlDataAdapter(selectCmd, myConnection);

			// set the CommandTimeout
			myCommand.SelectCommand.CommandTimeout = 60;  // seconds

			DataSet ds = new DataSet();
			myCommand.Fill(ds, "GPO");

			return ds.Tables[0];

		}

    }
}