﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GIS_WebAPI2.Models;
using System.Data;
using System.Web.Script.Serialization;

namespace GIS_WebAPI2.Controllers
{
    public class SampleResultsPivotController : ApiController
    {
		public IHttpActionResult Get(String pid, int startNumber=0)		{

			var result = new List<Dictionary<string, object>>();

			//DataSet DS = new DataSet();
			DataTable DT = new DataTable();
			Samples sp = new Models.Samples();
			//DT = sp.resultspivot(pid);
			DT = sp.resultsPivot(pid, startNumber);

			foreach (DataRow row in DT.Rows)
			{
				Dictionary<string, object> obj = new Dictionary<string, object>();
				foreach (DataColumn col in DT.Columns)
				{
					obj.Add(col.ColumnName, row[col.ColumnName]);
				}
				result.Add(obj);
			}

			var serializer = new JavaScriptSerializer();
			serializer.MaxJsonLength = 867530900;

			return Ok(result);
		}
	}
}
