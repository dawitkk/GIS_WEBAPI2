﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GIS_WebAPI2.Models;
using System.Dynamic;

namespace GIS_WebAPI2.Controllers
{
    public class ProjectsController : ApiController
    {
        public IHttpActionResult Get()
        {

            var result = new List<dynamic>();

            DataSet DS = new DataSet();
            Samples sp = new Models.Samples();
            DS = sp.projects();

            foreach (DataRow row in DS.Tables[0].Rows)
            {
                var obj = (IDictionary<string, object>)new ExpandoObject();
                foreach (DataColumn col in DS.Tables[0].Columns)
                {
                    obj.Add(col.ColumnName, row[col.ColumnName]);
                }
                result.Add(obj);
            }

            return Ok(result);
        }

    }
}
